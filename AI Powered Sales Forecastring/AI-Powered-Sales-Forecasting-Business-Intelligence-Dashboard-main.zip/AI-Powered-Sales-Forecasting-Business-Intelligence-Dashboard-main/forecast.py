import pandas as pd
from prophet import Prophet
import joblib

# =========================
# 1. LOAD DATA
# =========================
def load_data(file_path):

    # low_memory=False removes dtype warning
    df = pd.read_csv(file_path, low_memory=False)

    return df


# =========================
# 2. DATA PREPROCESSING
# =========================
def preprocess_data(df):

    # convert date safely
    df['date'] = pd.to_datetime(
        df['date'],
        errors='coerce',
        format='mixed'
    )

    # remove invalid dates
    df = df.dropna(subset=['date'])

    # convert sales column to numeric
    df['sum_total'] = pd.to_numeric(
        df['sum_total'],
        errors='coerce'
    )

    # remove invalid sales rows
    df = df.dropna(subset=['sum_total'])

    # aggregate transactional data into daily sales
    df = df.groupby('date')['sum_total'].sum().reset_index()

    # prophet required format
    df.columns = ['ds', 'y']

    return df


# =========================
# 3. TRAIN MODEL
# =========================
def train_model(df):

    model = Prophet(
        yearly_seasonality=True,
        weekly_seasonality=True,
        daily_seasonality=False
    )

    model.fit(df)

    return model


# =========================
# 4. MAKE FUTURE FORECAST ONLY 2027
# =========================
def make_forecast(model):

    # Create future dates
    future = model.make_future_dataframe(
        periods=730
    )

    # Predict
    forecast = model.predict(future)

    # Keep only 2027
    forecast_2027 = forecast[
        (forecast['ds'] >= '2027-01-01') &
        (forecast['ds'] <= '2027-12-31')
    ]

    return forecast_2027

# =========================
# 5. SAVE MODEL
# =========================
def save_model(model, path="models/model.pkl"):

    joblib.dump(model, path)


# =========================
# 6. SAVE FORECAST
# =========================
def save_forecast(forecast, path="forecast.csv"):

    forecast.to_csv(path, index=False)


# =========================
# 7. MAIN EXECUTION
# =========================
if __name__ == "__main__":

    # dataset path
    file_path = r"C:\Users\Sanjana\Desktop\Sales forecasting system\dataset\sales.csv"

    try:

        # load data
        df = load_data(file_path)

        # preprocess data
        df = preprocess_data(df)

        print("✅ Data after preprocessing:")
        print(df.head())

        # train model
        model = train_model(df)

        print("✅ Model trained successfully")

        # forecast future (2026 + 2027)
        forecast = make_forecast(model)

        print("✅ Forecast generated successfully")

        # save model
        save_model(model)

        # save forecast output
        save_forecast(forecast)

        print("✅ forecast.csv saved successfully")
        print("✅ model.pkl saved successfully")

        # show predictions
        print("\n📊 Forecast Preview:")
        print(
            forecast[
                ['ds', 'yhat', 'yhat_lower', 'yhat_upper']
            ].tail()
        )

    except Exception as e:

        print(f"\n❌ ERROR: {e}")