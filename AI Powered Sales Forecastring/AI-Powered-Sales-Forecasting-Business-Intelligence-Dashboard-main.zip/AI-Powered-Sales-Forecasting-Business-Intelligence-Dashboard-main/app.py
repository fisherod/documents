import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import joblib
import plotly.express as px
# ✅ MODEL LOAD HERE
ml_model = joblib.load("models/model.pkl")

from streamlit_option_menu import option_menu
# PDF REPORT IMPORTS
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer
)

from reportlab.lib.styles import (
    getSampleStyleSheet
)
@st.cache_data
def load_csv(path, **kwargs):
    return pd.read_csv(path, **kwargs)

# =====================================================
# CONFIG
# =====================================================

st.set_page_config(
    page_title="AI-Powered Sales Forecasting & Business Intelligence Dashboard",
    page_icon="📊",
    layout="wide"
)


# =====================================================
# DARK PROFESSIONAL THEME
# =====================================================
st.markdown("""
<style>

/* Main App */
.stApp {
    background-color: #0E1117;
    color: white;
}

/* Sidebar */
section[data-testid="stSidebar"] {
    background-color: #161B22;
}

/* Metric Cards */
div[data-testid="metric-container"] {
    background: linear-gradient(
        135deg,
        #00ADB5,
        #393E46
    );

    border-radius: 16px;

    padding: 18px;

    box-shadow: 0 4px 15px rgba(0,0,0,0.4);

    border: none;

    transition: 0.3s;
}

/* Hover Effect */
div[data-testid="metric-container"]:hover {

    transform: translateY(-5px);

    box-shadow: 0 8px 20px rgba(0,0,0,0.5);
}

/* Dataframe */
[data-testid="stDataFrame"] {
    background-color: #1E1E1E;
}

/* Buttons */
.stButton > button {
    background-color: #00ADB5;
    color: white;
    border-radius: 8px;
    border: none;
}

/* Input Boxes */
.stNumberInput input {
    background-color: #1E1E1E;
    color: white;
}

/* Selectbox */
.stSelectbox div {
    background-color: #1E1E1E;
    color: white;
}

/* Multiselect */
.stMultiSelect div {
    background-color: #1E1E1E;
    color: white;
}

/* Titles */
h1, h2, h3, h4 {
    color: white;
}

/* Paragraph Text */
p, label, div {
    color: white;
}

</style>
""", unsafe_allow_html=True)

# =====================================================
# LOAD DATA
# =====================================================
data = load_csv("dataset/sales.csv")

if "Unnamed: 0" in data.columns:
    data = data.drop(columns=["Unnamed: 0"])

# Remove missing values
data = data.dropna()
data = data.drop_duplicates()
# Date Conversion
if "date" in data.columns:

    data["date"] = pd.to_datetime(
        data["date"],
        errors="coerce"
    )

    # Remove invalid dates
    data = data.dropna(subset=["date"])

# Load Model
model = joblib.load("models/model.pkl")

# =====================================================
# LOAD FORECAST DATA
# =====================================================

forecast = load_csv(
    "dataset/future_forecast.csv",
    sep=r"\s+",
    header=None,
    names=["Date", "actual", "predicted"]
)

forecast["Date"] = pd.to_datetime(
    forecast["Date"],
    format="%d-%m-%Y"
)
# =====================================================
# LOAD MARKDOWN DATA
# =====================================================

markdown_df = load_csv(
    "dataset/markdowns.csv"
)

markdown_df.columns = (
    markdown_df.columns
    .str.strip()
    .str.lower()
)
# =====================================================
# LOAD ONLINE SALES DATA
# =====================================================

online_df = load_csv(
    "dataset/online.csv"
)

# =====================================================
# LOAD ACTUAL MATRIX
# =====================================================

actual_df = load_csv(
    "dataset/actual_matrix.csv"
)
# =====================================================
# LOAD CATALOG DATA
# =====================================================

catalog_df = load_csv(
    "dataset/catalog.csv",
    encoding="latin1"
)

# =====================================================
# CLEAN COLUMN NAMES
# =====================================================

data.columns = data.columns.str.strip().str.lower()
catalog_df.columns = catalog_df.columns.str.strip().str.lower()

# =====================================================
# CLEAN item_id
# =====================================================

data["item_id"] = (
    data["item_id"]
    .astype(str)
    .str.upper()
    .str.strip()
)

catalog_df["item_id"] = (
    catalog_df["item_id"]
    .astype(str)
    .str.upper()
    .str.strip()
)

# =====================================================
# MERGE SALES + CATALOG
# =====================================================

merged_df = pd.merge(
    data,
    catalog_df,
    on="item_id",
    how="left"
)

# Remove unmatched rows
merged_df = merged_df.dropna(
    subset=["product_name"]
)

# =====================================================
# DEBUG CHECK
# =====================================================

st.write("Merged Rows:", merged_df.shape)

# =====================================================
# SIDEBAR
# =====================================================
with st.sidebar:

    st.markdown("## 📈 Sales Intelligence Hub")

    selected = option_menu(
    menu_title=None,
options=[
        "Dashboard",
        "Sales Analytics",
        "Product Insights",
        "Business Reports",
        "Sales Forecast",
        "Time Series Forecast",
        "AI Insights",
        "Data Explorer",
        "Download Center",
        "About Project"
    ],
    icons=[
        "speedometer2",
        "graph-up",
        "boxes",
        "clipboard-data",
        "cash-coin",
        "activity",
        "robot",
        "search",
        "download",
        "info-circle"
    ],
    
        
   
        default_index=0,
        styles={
            "container": {
                "padding": "6px",
                "background-color": "#161B22",
                "border-radius": "12px",
            },

            "icon": {
                "color": "#00ADB5",
                "font-size": "18px",
            },

            "nav-link": {
                "font-size": "15px",
                "text-align": "left",
                "margin": "5px",
                "--hover-color": "#222831",
                "color": "white",
            },

            "nav-link-selected": {
                "background-color": "#00ADB5",
                "color": "white",
            },
        }
    )
    st.markdown("---")

# =====================================================
# DASHBOARD
# =====================================================
if selected == "Dashboard":

    st.title("📊AI-Powered Sales Forecasting & Business Intelligence Dashboard")
    total_sales = data["sum_total"].sum()
    total_qty = int(data["quantity"].sum())
    total_orders = len(data)

    col1, col2, col3 = st.columns(3)

    col1.metric("💰 Revenue", f"₹ {total_sales:,.0f}")
    col2.metric("📦 Quantity", f"{total_qty:,}")
    col3.metric("🛒 Orders", f"{total_orders:,}") 

    st.markdown("---")

    st.subheader("📈 Revenue Trend")

    daily = (
        data.groupby("date")["sum_total"]
        .sum()
        .reset_index()
    )

    fig = px.line(
        daily,
        x="date",
        y="sum_total",
        title="Daily Revenue Trend",
        markers=True
    )

    fig.update_layout(
       template="plotly_dark",
       xaxis_title="Date",
       yaxis_title="Revenue"
    )

    st.plotly_chart(fig, use_container_width=True)


    # Download Report
    csv = data.to_csv(index=False)

    st.download_button(
        label="📥 Download Sales Report (CSV)",
        data=csv,
        file_name="sales_report.csv",
        mime="text/csv"
    )

    st.markdown("---")

    st.subheader("📈 Revenue Trend")

    daily = (
        data.groupby("date")["sum_total"]
        .sum()
        .reset_index()
    )

    fig, ax = plt.subplots(figsize=(16, 6))

    ax.plot(
        daily["date"],
        daily["sum_total"],
        marker="o",
        linewidth=2
    )

    ax.xaxis.set_major_locator(
        mdates.AutoDateLocator()
    )

    ax.xaxis.set_major_formatter(
        mdates.DateFormatter("%Y-%m-%d")
    )

    ax.set_xlabel("Date")
    ax.set_ylabel("Revenue")
    ax.set_title("Daily Revenue Trend")

    plt.xticks(rotation=45)
    plt.tight_layout()

    st.pyplot(fig)
    plt.close(fig)
# =====================================================
# SALES ANALYTICS
# =====================================================
elif selected == "Sales Analytics":

    st.title("📊 Sales Analytics")

    st.dataframe(data.head(50))

    st.subheader("🏪 Store Performance")

    store = (
        data.groupby("store_id")["sum_total"]
        .sum()
        .reset_index()
    )

    fig, ax = plt.subplots(figsize=(14, 6))

    ax.bar(
        store["store_id"].astype(str),
        store["sum_total"]
    )

    ax.set_title("Store Revenue")
    ax.set_xlabel("Store ID")
    ax.set_ylabel("Revenue")

    plt.tight_layout()

    st.pyplot(fig)
    plt.close(fig)

# =====================================================
# PRODUCT INSIGHTS
# =====================================================
elif selected == "Product Insights":

    st.title("📦 Product Insights Dashboard")

    st.sidebar.subheader("🔍 Product Filters")

    category_filter = st.sidebar.multiselect(
        "Select Category",
        merged_df["category"].dropna().unique()
    )

    filtered_df = merged_df.copy()

    if category_filter:
        filtered_df = filtered_df[
            filtered_df["category"].isin(category_filter)
        ]

    # KPI Cards
    total_products = filtered_df["item_id"].nunique()
    total_categories = filtered_df["category"].nunique()
    total_revenue = filtered_df["sum_total"].sum()

    col1, col2, col3 = st.columns(3)

    col1.metric("📦 Products", total_products)
    col2.metric("🗂️ Categories", total_categories)
    col3.metric("💰 Revenue", f"₹ {total_revenue:,.0f}")

    st.markdown("---")

    # Top Products
    st.subheader("🏆 Top 10 Products")

    top_products = (
        filtered_df.groupby("product_name")["sum_total"]
        .sum()
        .sort_values(ascending=False)
        .head(10)
        .reset_index()
    )

    fig1 = px.bar(
        top_products,
        x="product_name",
        y="sum_total",
        text_auto=True,
        title="Top Products by Revenue"
    )

    st.plotly_chart(fig1, use_container_width=True)

    # Category Revenue
    st.subheader("📊 Category Wise Revenue")

    category_sales = (
        filtered_df.groupby("category")["sum_total"]
        .sum()
        .reset_index()
    )

    fig2 = px.pie(
        category_sales,
        names="category",
        values="sum_total",
        hole=0.4
    )

    st.plotly_chart(fig2, use_container_width=True)

    # Price Analysis
    st.subheader("💵 Price vs Revenue")

    plot_df = filtered_df.sample(
    min(5000, len(filtered_df)),
    random_state=42
)

    fig3 = px.scatter(
        filtered_df,
        x="price",
        y="sum_total",
        color="category",
        hover_data=["product_name"]
    )

    st.plotly_chart(fig3, use_container_width=True)

    # Product Table
    st.subheader("📋 Product Details")

    st.dataframe(
        filtered_df[
            [
                "item_id",
                "product_name",
                "category",
                "brand",
                "price",
                "sum_total"
            ]
        ].head(50),
        use_container_width=True
    )


# =====================================================
# BUSINESS REPORTS
# =====================================================
elif selected == "Business Reports":

    st.title("📑 Business Reports Dashboard")

    # =====================================================
    # KPI CARDS
    # =====================================================

    total_revenue = data["sum_total"].sum()

    total_orders = len(data)

    avg_order = (
        total_revenue / total_orders
    )

    top_store = (
        data.groupby("store_id")["sum_total"]
        .sum()
        .idxmax()
    )

    col1, col2, col3, col4 = st.columns(4)

    col1.metric(
        "💰 Total Revenue",
        f"₹ {total_revenue:,.0f}"
    )

    col2.metric(
        "🛒 Total Orders",
        total_orders
    )

    col3.metric(
        "📈 Avg Order Value",
        f"₹ {avg_order:,.0f}"
    )

    col4.metric(
        "🏪 Top Store",
        top_store
    )

    st.markdown("---")

    # =====================================================
    # MONTHLY SALES TREND
    # =====================================================

    st.subheader("📊 Monthly Revenue Trend")

    monthly_sales = (
        data.groupby(
            data["date"].dt.to_period("M")
        )["sum_total"]
        .sum()
        .reset_index()
    )

    monthly_sales["date"] = (
        monthly_sales["date"]
        .astype(str)
    )

    fig1 = px.line(
        monthly_sales,
        x="date",
        y="sum_total",
        markers=True,
        title="Monthly Revenue Trend"
    )

    st.plotly_chart(
        fig1,
        use_container_width=True
    )

    # =====================================================
    # STORE PERFORMANCE
    # =====================================================

    st.subheader("🏪 Store Performance")

    store_sales = (
        data.groupby("store_id")["sum_total"]
        .sum()
        .reset_index()
    )

    fig2 = px.bar(
        store_sales,
        x="store_id",
        y="sum_total",
        color="sum_total",
        title="Store Revenue"
    )

    st.plotly_chart(
        fig2,
        use_container_width=True
    )
    
    
    # =====================================================
    # DISCOUNT ANALYSIS
    # =====================================================

    st.subheader("🏷️ Discount Analysis")

    discount_df = pd.read_csv(
        "dataset/discounts_history.csv"
    )

    if "discount" in discount_df.columns:

        fig4 = px.histogram(
            discount_df,
            x="discount",
            nbins=20,
            title="Discount Distribution"
        )

        st.plotly_chart(
            fig4,
            use_container_width=True
        )

    # =====================================================
    # TOP DISCOUNT PRODUCTS
    # =====================================================

    if (
        "item_id" in discount_df.columns
        and "discount" in discount_df.columns
    ):

        top_discount = (
            discount_df.groupby("item_id")["discount"]
            .mean()
            .sort_values(ascending=False)
            .head(10)
            .reset_index()
        )

        st.subheader("🔥 Top Discounted Products")

        fig5 = px.bar(
            top_discount,
            x="item_id",
            y="discount",
            color="discount",
            title="Highest Discount Products"
        )

        st.plotly_chart(
            fig5,
            use_container_width=True
        )

    # =====================================================
    # DATASET SUMMARY
    # =====================================================

    st.subheader("📋 Dataset Summary")

    st.dataframe(
        data.describe(),
        use_container_width=True
    )

    # =====================================================
    # MISSING VALUES
    # =====================================================

    st.subheader("⚠️ Missing Values")

    missing = data.isnull().sum()

    missing = missing[missing > 0]

    if missing.empty:

        st.success(
            "✅ No Missing Values Found"
        )

    else:

        st.write(missing)

# =====================================================
# SALES FORECAST
# =====================================================
elif selected == "Sales Forecast":
    # =========================
    # Prediction System
    # =========================
    import streamlit as st
    import pandas as pd
    import joblib
    # Load Model
    ml_model = joblib.load("models/model.pkl")

    st.title("📈 Prediction System")
    # Inputs
    qty = st.number_input(
        "Quantity",
        min_value=1,
        step=1
    )
    price = st.number_input(
       "Price",
        min_value=0.0,
        step=1.0
    )
    store_id = st.number_input(
        "Store ID",
        min_value=1,
        step=1
    )
    future_date = st.date_input("Select Date") 
    # Predict
    if st.button("Predict"): 

         dt = pd.to_datetime(future_date)
         future = pd.DataFrame({
             "quantity": [int(qty)],
             "price_base": [float(price)],
             "store_id": [int(store_id)],
             "day": [int(dt.day)],
             "month": [int(dt.month)],
             "year": [int(dt.year)]
         })
          # Debug (temporarily)
    st.write("Input Data")
    st.write(future)

    st.write("Data Types")
    st.write(future.dtypes)

    pred = ml_model.predict(future)

    st.success(
        f"Predicted Revenue: ₹ {pred[0]:,.2f}"
    )

elif selected == "Time Series Forecast":

    st.title("📈 AI Sales Forecast Dashboard")

    # -----------------------------
    # PREPARE DATA
    # -----------------------------
    df_ts = data.groupby("date")["sum_total"].sum().reset_index()
    df_ts = df_ts.rename(columns={"date": "ds", "sum_total": "y"})
    df_ts["ds"] = pd.to_datetime(df_ts["ds"])
    # -----------------------------
    # BACKTESTING (TRAIN-TEST SPLIT)
    # -----------------------------
    train_size = int(len(df_ts) * 0.8)

    train = df_ts[:train_size]
    test = df_ts[train_size:]

    from prophet import Prophet
    from sklearn.metrics import mean_squared_error
    import numpy as np

    bt_model = Prophet(yearly_seasonality=True)
    bt_model.fit(train)

    future_bt = bt_model.make_future_dataframe(periods=len(test))
    forecast_bt = bt_model.predict(future_bt)

    test_pred = forecast_bt["yhat"].iloc[train_size:].values

    rmse_bt = np.sqrt(mean_squared_error(test["y"], test_pred))

    st.subheader("📊 Backtesting Result")
    st.metric("Test RMSE", f"{rmse_bt:,.2f}")

    # -----------------------------
    # TRAIN MODEL (Prophet)
    # -----------------------------
    from prophet import Prophet

    model = Prophet(
        yearly_seasonality=True,
        weekly_seasonality=True,
        daily_seasonality=False,
        interval_width=0.75
    )

    model.fit(df_ts)

    # -----------------------------
    # PREDICTION
    # -----------------------------
    future = model.make_future_dataframe(periods=365)

    forecast_prophet = model.predict(future)

    # Remove negative forecast values
    forecast_prophet["yhat"] = forecast_prophet["yhat"].clip(lower=0)

    forecast_prophet["yhat_lower"] = (
        forecast_prophet["yhat_lower"]
        .clip(lower=forecast_prophet["yhat"] * 0.5)
    )
    # =====================================================
    # MODEL EVALUATION METRICS  
    # =====================================================
    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
    import numpy as np

    actual = df_ts["y"]
    predicted = forecast_prophet["yhat"].iloc[:len(df_ts)]

    rmse = np.sqrt(mean_squared_error(actual, predicted))
    mae = mean_absolute_error(actual, predicted)
    mape = np.mean(np.abs((actual - predicted) / actual)) * 100
    r2 = r2_score(actual, predicted)

    st.subheader("📊 Model Accuracy Metrics")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("RMSE", f"{rmse:,.2f}")
    col2.metric("MAE", f"{mae:,.2f}")
    col3.metric("MAPE", f"{mape:.2f}%")
    col4.metric("R² Score", f"{r2:.3f}")

    # -----------------------------
    # ACTUAL vs PREDICTED CHART
    # -----------------------------
    st.subheader("📈 Actual vs Predicted Comparison")

    fig_acc = px.line()

    fig_acc.add_scatter(x=df_ts["ds"], y=actual, name="Actual")
    fig_acc.add_scatter(x=df_ts["ds"], y=predicted, name="Predicted")

    st.plotly_chart(fig_acc, use_container_width=True)
    # -----------------------------
    # ANOMALY DETECTION
    # -----------------------------
    df_ts["rolling_mean"] = (
        df_ts["y"]
        .rolling(7)
        .mean()
    )

    df_ts["rolling_std"] = (
        df_ts["y"]
        .rolling(7)
        .std()
    )

    df_ts["anomaly"] = (
        abs(
            df_ts["y"]
            - df_ts["rolling_mean"]
        )
        >
        2 * df_ts["rolling_std"]
    )

    st.subheader("🚨 Sales Anomalies")

    anomalies = df_ts[
        df_ts["anomaly"] == True
    ]

    st .dataframe(anomalies) 

    fig_anomaly = px.scatter(
        anomalies,
        x="ds",
        y="y",
        title="Detected Sales Anomalies"
    )

    st.plotly_chart(
        fig_anomaly,
        use_container_width=True
    )


    # -----------------------------
    # MODEL HEALTH INDICATOR
    # -----------------------------
    accuracy = max(0, 100 -mape)
    if accuracy > 90:
        st.success(
            f"🟢 Excellent Model Accuracy: {accuracy:.2f}%"
        )
    elif accuracy > 75:
       st.warning(
           f"🟡 Good Model Accuracy: {accuracy:.2f}%"
       )
    else:
        st.error(
             f"🔴 Model Needs Improvement: {accuracy:.2f}%"
         )
    # -----------------------------
    # DATA VIEW
    # -----------------------------
    st.subheader("📊 Forecast Data (Last 30 Days)")

    st.dataframe(
        forecast_prophet[
            ["ds", "yhat", "yhat_lower", "yhat_upper"]
        ].tail(30)
    )

    # -----------------------------
    # DOWNLOAD CSV
    # -----------------------------
    forecast_csv = forecast_prophet.to_csv(index=False)

    st.download_button(
        label="📥 Download Forecast Data",
        data=forecast_csv,
        file_name="sales_ forecast.csv",
        mime="text/csv"
    )

    # -----------------------------
    # FORECAST PLOT
    # -----------------------------
    fig = model.plot(forecast_prophet)

    st.pyplot(fig)

    # -----------------------------
    # COMPONENTS
    # -----------------------------
    st.subheader("📈 Trend & Seasonality")

    fig2 = model.plot_components(forecast_prophet)

    st.pyplot(fig2)

# =====================================================
# AI INSIGHTS
# =====================================================
elif selected == "AI Insights":

    st.title("🤖 AI Business Insights")

    total_sales = data["sum_total"].sum()

    total_orders = len(data)

    avg_order_value = (
        total_sales / total_orders
    )

    best_store = (
        data.groupby("store_id")["sum_total"]
        .sum()
        .idxmax()
    )

    best_product = (
        merged_df.groupby("product_name")["sum_total"]
        .sum()
        .idxmax()
    )

    top_day = (
        data.groupby("date")["sum_total"]
        .sum()
        .idxmax()
    )

    col1, col2 = st.columns(2)

    col1.metric(
        "🏪 Top Store",
        best_store
    )

    col2.metric(
        "📦 Best Product",
        best_product
    )

    st.markdown("---")

    st.subheader("📊 Smart Business Insights")

    st.success(
        f"💰 Total Revenue Generated: ₹ {total_sales:,.0f}"
    )

    st.info(
        f"🛒 Average Order Value: ₹ {avg_order_value:,.0f}"
    )

    st.success(
        f"🏪 Store {best_store} generated the highest revenue."
    )

    st.success(
        f"📦 '{best_product}' is the best-selling product."
    )

    st.warning(
        f"📅 Highest sales were recorded on {top_day.strftime('%d-%m-%Y')}."
    )

    st.info(
        "📈 Revenue trend indicates growth opportunities for high-performing products."
    )

    st.info(
        "🎯 Consider increasing inventory for top-selling products."
    )
elif selected == "Data Explorer":

    st.title("🔍 Data Explorer")

    st.write("Dataset Shape:", data.shape)

    # Column selection
    selected_columns = st.multiselect(
        "Select Columns",
        data.columns,
        default=list(data.columns)
    )

    # Row limiter (IMPORTANT FIX)
    rows = st.slider(
        "Number of Rows to Display",
        min_value=100,
        max_value=5000,
        value=1000
    )

    # Safe dataframe rendering (FIX ERROR)
    st.dataframe(
        data[selected_columns].head(rows),
        use_container_width=True
    )

    # Quick stats (optional but useful)
    st.markdown("---")
    st.subheader("📊 Quick Summary")

    st.write(data[selected_columns].describe())
# =====================================================
# DOWNLOAD CENTER
# =====================================================
elif selected == "Download Center":

    st.title("📥 Download Center")

    sales_csv = data.to_csv(index=False)

    st.download_button(
        "📥 Download Sales Dataset",
        sales_csv,
        "sales_dataset.csv",
        "text/csv"
    )
    import io

    pdf_buffer = io.BytesIO()

    doc = SimpleDocTemplate(pdf_buffer)

    styles = getSampleStyleSheet()

    elements = []

    elements.append(
        Paragraph(
            "Sales Forecasting Report",
            styles["Title"]
       )
    )

    elements.append(
        Paragraph(
            f"Total Revenue: ₹ {data['sum_total'].sum():,.0f}",
            styles["BodyText"]
        )
    )
    elements.append(
        Paragraph(
            f"Total Orders: {len(data)}",
            styles["BodyText"]
        )
    )
    elements.append(
        Paragraph(
            f"Total Quantity Sold: {int(data['quantity'].sum()):,}",
            styles["BodyText"]
        )
    )
    elements.append(
        Paragraph(
            f"Average Order Value: ₹ {(data['sum_total'].sum()/len(data)):,.0f}",
            styles["BodyText"]
        )
    )
    elements.append(
        Paragraph(
            f"Top Store: {data.groupby('store_id')['sum_total'].sum().idxmax()}",
            styles["BodyText"]
        )
    )

    elements.append(
        Paragraph(
            "Report Generated On: {pd.Timestamp.now().strftime('%d-%m-%Y %H:%M')}",
             styles["BodyText"]
        )
    )
    elements.append(
        Spacer(1, 20)
    )

    elements.append(
        Paragraph(
            "Generated by Sales Forecasting System",
             styles["Italic"]
        )
    )


    doc.build(elements)

    pdf_buffer.seek(0)

    st.download_button(
        "📄 Download PDF Report",
        pdf_buffer,
        "sales_report.pdf",
        "application/pdf"
    )

# =====================================================
# ABOUT PROJECT
# =====================================================
elif selected == "About Project":

    st.title("ℹ️ About Project")

    st.markdown("""
    ## Sales Forecasting System

    ### Technologies Used
    - Python
    - Pandas
    - Streamlit
    - Matplotlib
    - Plotly
    - Prophet
    - Machine Learning

    ### Features
    ✅ Dashboard

    ✅ Sales Analytics

    ✅ Product Insights

    ✅ Business Reports

    ✅ Sales Prediction

    ✅ Time Series Forecasting

    ✅ AI Insights

    ✅ Data Explorer

    ✅ Download Center
    """)



# =====================================================
# FOOTER
# =====================================================
st.markdown("---")

st.markdown(
    """
    <center style='color:lightgray; font-size:16px;'>
         Built with Python | Streamlit | Pandas |
         Matplotlib | Plotly | Prophet
    </center>
    """,
    unsafe_allow_html=True
)