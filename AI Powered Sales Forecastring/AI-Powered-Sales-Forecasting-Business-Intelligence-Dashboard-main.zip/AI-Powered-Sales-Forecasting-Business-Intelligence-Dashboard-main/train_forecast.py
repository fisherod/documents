import pandas as pd
from prophet import Prophet

# =====================================================
# LOAD DATA
# =====================================================
data = pd.read_csv("dataset/sales.csv")

# =====================================================
# CLEAN DATA
# =====================================================

# Convert date column
data["date"] = pd.to_datetime(data["date"], errors="coerce")

# Drop invalid rows
data = data.dropna(subset=["date", "sum_total"])

# Remove duplicates
data = data.drop_duplicates()

# Ensure no negative sales
data = data[data["sum_total"] >= 0]

# =====================================================
# AGGREGATE DAILY SALES
# =====================================================

df = data.groupby("date")["sum_total"].sum().reset_index()

# Rename for Prophet
df = df.rename(columns={
    "date": "ds",
    "sum_total": "y"
})

# =====================================================
# PROPHET MODEL (IMPROVED)
# =====================================================

model = Prophet(
    yearly_seasonality=True,
    weekly_seasonality=True,
    daily_seasonality=False,
    changepoint_prior_scale=0.05,
    seasonality_mode="multiplicative"
)

# Train model
model.fit(df)

# =====================================================
# CREATE FUTURE DATAFRAME
# =====================================================

future = model.make_future_dataframe(periods=365)

# =====================================================
# PREDICT
# =====================================================

forecast = model.predict(future)

# =====================================================
# SAFETY FIX (NO NEGATIVE SALES)
# =====================================================

forecast["yhat"] = forecast["yhat"].clip(lower=0)
forecast["yhat_lower"] = forecast["yhat_lower"].clip(lower=0)
forecast["yhat_upper"] = forecast["yhat_upper"].clip(lower=0)

# =====================================================
# SAVE OUTPUT
# =====================================================

forecast.to_csv("forecast.csv", index=False)

print("✅ Forecast generated successfully!")
print("📁 Saved as forecast.csv")