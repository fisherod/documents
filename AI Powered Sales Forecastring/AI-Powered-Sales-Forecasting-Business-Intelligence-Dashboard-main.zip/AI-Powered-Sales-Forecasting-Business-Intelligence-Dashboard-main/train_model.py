print("TRAINING STARTED...")

import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor

print("Loading dataset...")
data = pd.read_csv("dataset/sales.csv", low_memory=False)

print("Dataset loaded")

data.columns = data.columns.str.strip().str.lower()

print("Converting date...")
data["date"] = pd.to_datetime(data["date"], errors="coerce")

data["day"] = data["date"].dt.day
data["month"] = data["date"].dt.month
data["year"] = data["date"].dt.year

print("Removing NaN...")
data = data.dropna(subset=[
    "quantity",
    "price_base",
    "store_id",
    "sum_total",
    "day",
    "month",
    "year"
])

print("Rows after cleaning:", len(data))
print("Sampling data...")
data = data.sample(
    n=50000,
    random_state=42
)

print("Rows after sampling:", len(data))

X = data[
    [
        "quantity",
        "price_base",
        "store_id",
        "day",
        "month",
        "year"
    ]
]

y = data["sum_total"]

print("Training model...")

model = RandomForestRegressor(
    n_estimators=20,   # temporarily reduce from 100
    random_state=42,
    n_jobs=-1
)

model.fit(X, y)

print("Model trained")

joblib.dump(model, "models/model.pkl")

print("✅ Model saved successfully")